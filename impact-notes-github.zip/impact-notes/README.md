# IMPACT NOTES

A minimalist, local-first notes website with offline support and shareable note links.

## Features
- Create, edit, search, and delete notes
- Autosaves notes in the browser's local storage
- Works offline after the site has been loaded once, when hosted over HTTPS and the service worker has installed
- Share a note with the device's native share sheet or copy a link
- Export a note to `.txt`
- Responsive desktop and mobile layout
- Bold condensed headings, dark UI, and acid-lime accent

## Run locally
For a quick preview, open `index.html` in a browser. Note: service workers are disabled on ordinary `file://` URLs, so offline website caching will not work in this mode.

For full PWA/offline caching, serve the folder over localhost, for example:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish with GitHub Pages
1. Create a GitHub repository named `impact-notes` (or any name you like).
2. Upload `index.html`, `manifest.json`, and `sw.js` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then save.
6. Open the published HTTPS website once while online. Wait for it to load fully; then it can be cached for offline use.

## Important sharing note
The Share button creates a self-contained URL containing the note text. This means:
- No server or account is required to share.
- The recipient can open the link online and the note will be imported into their own browser storage.
- Anyone who has the link can read its contents. Do not share private or sensitive notes this way.
- Long notes create long URLs, and some apps may truncate them.
- This is link-based sharing, not cloud sync. Edits made after sharing do not update the already-sent link.
- For private links, user accounts, revocation, or live syncing between devices, add a backend/database (for example Supabase or Firebase) and access controls.

## Offline storage notes
Notes are saved only in the current browser on the current device. They do not automatically sync across browsers or devices. Clearing site data can delete local notes, so export important notes regularly.
